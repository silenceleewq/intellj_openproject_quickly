#parse("C File Header.h")
#import "${HEADER_FILENAME}"

@interface ${NAME}()

@end

@implementation ${NAME} #if ($PUT_IVARS_TO_IMPLEMENTATION == "true"){  }

- (void)viewDidLoad {
  [super viewDidLoad];
  // Do any additional setup after loading the view.
  #end
  
  
}

@end