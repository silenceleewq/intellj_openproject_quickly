
/** $IVAR lazy load */

if ($IVAR == nil) {
#if ($RETURN_TYPE.endsWith("*"))
  #set($VAR_CLASS = $RETURN_TYPE.substring(0, $RETURN_TYPE.lastIndexOf("*")).trim())
#else
  #set($VAR_CLASS = $RETURN_TYPE)
#end
$IVAR = [$VAR_CLASS new];
}
return $IVAR;