#parse("C File Header.h")
#import <UIKit/UIKit.h>


@interface ${NAME} : UIViewController #if ($PUT_IVARS_TO_IMPLEMENTATION != "true"){

}
#end
@end